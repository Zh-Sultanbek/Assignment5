package com.company;

import java.util.Scanner;
public class Main extends price  {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Main first = new Main();
        boolean menu = true;
        int id=0;
        while (menu) {
            id++;
            System.out.println("1.price");
            System.out.println("2.order");
            System.out.println("3.Closing");
            int n = input.nextInt();
            switch (n) {
                case 1:
                    System.out.println("Each IT service cost" + n );
                    break;

                case 2:
                    first.order(id);
                    break;

                case 3:
                    menu = false;
                    break;
                default:
                    System.out.println("Please, print number have in menu\n");
                    break;
            }
        }
        System.out.print("Closed!\n");
    }




    public void order(int id){
        Scanner input = new Scanner(System.in);
        System.out.println("Your name:");
        String clientName = input.nextLine();
        System.out.println("\n");
        System.out.println("project name");
        String projectName = input.nextLine();
        System.out.println("\n");
        System.out.println("How many employees do u need?");
        int numEmp = input.nextInt();
        int total = numEmp*n;
        inputDB insertt = new inputDB(id,clientName,projectName,numEmp,total);
        System.out.println(" ");    }


    }

