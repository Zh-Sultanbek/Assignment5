package com.company;
import java.sql.*;
public class inputDB
{
    String connectionUrl="jdbc:postgresql://localhost:5432/postgres";
    Connection con;
    ResultSet insert;
    Statement stmt ;
    public inputDB(int id, String clientName, String projectName, int numEmp, int total){
        try
        {
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection(connectionUrl,"postgres","sula0113");
            stmt = con.createStatement();
            insert = stmt.executeQuery("insert into std(id,name ,project,employee,total) values(" + id + ",'" + clientName + "','" + projectName + "','" + numEmp + "')");
        }
        catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (SQLException e)
        {
            //e.printStackTrace();
        }
    }
}
