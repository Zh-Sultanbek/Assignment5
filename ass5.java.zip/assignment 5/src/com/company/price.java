package com.company;

public class price {
    private int price=1000;

    public int getPrice() {
        return price;
    }
    price m = new price();
    public int cost = m.getPrice();
    int n = cost;//if i won't create new variable, I can't be use variable cost directly. I will have to do it static
}
